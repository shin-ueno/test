//package com.example.timersample;
//
//import android.app.Activity;
//import android.os.Bundle;
//import android.os.CountDownTimer;
//import android.view.View;
//import android.view.View.OnClickListener;
//import android.widget.Button;
//import android.widget.TextView;
//import android.widget.Toast;
//
//
//public class MainActivity extends Activity {
//
//	private long timerCount = 0;
//	private CountDownTimer countDownTimer;
//
//	@Override
//	protected void onCreate(Bundle savedInstanceState) {
//		super.onCreate(savedInstanceState);
//		setContentView(R.layout.activity_main);
//
//		Button startbtn = (Button) findViewById(R.id.startbtn);
//		startbtn.setOnClickListener(new OnClickListener() {
//
//			@Override
//			public void onClick(View v) {
//				if (countDownTimer != null) {
//					timerCount = 0;
//					countDownTimer.cancel();
//				}
//
//				countDownTimer = new CountDownTimer(60000, 10) {
//
//					// �J�E���g�_�E������
//					public void onTick(long millisUntilFinished) {
//						TextView timeTextView = (TextView) findViewById(R.id.timeTextView);
//						timerCount++;
//						int second = (int) timerCount/100;
//						int comma = (int) timerCount%100;
//						timeTextView.setText((second + "�b" + comma).toString());
//					}
//
//					// �J�E���g��0�ɂȂ������̏���
//					public void onFinish() {
//						countDownTimer.cancel();
//					}
//				}.start();
//
//			}
//		});
//
//		Button stopbtn = (Button) findViewById(R.id.stopbtn);
//		stopbtn.setOnClickListener(new OnClickListener() {
//			@Override
//			public void onClick(View v) {
//
//			}
//		});
//	}
//
//	@Override
//	protected void onPause() {
//		super.onPause();
//		cancelTimer();
//	}
//
//	//�J�E���g���~�߂�
//	private void cancelTimer() {
//		if (countDownTimer != null) {
//			countDownTimer.cancel();
//		}
//	}}
package com.example.timersample;

import java.text.SimpleDateFormat;
import java.util.Date;

import android.app.Activity;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;


public class MainActivity extends Activity {
	private long startTime;
	private long stopTime;
	private CountDownTimer countDownTimer;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		Button startbtn = (Button) findViewById(R.id.startbtn);
		startbtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (countDownTimer != null) {
					countDownTimer.cancel();
				}
				startTime = System.currentTimeMillis();

				countDownTimer = new CountDownTimer(60000, 1) {

					// �J�E���g�_�E������
					public void onTick(long millisUntilFinished) {
//						stopTime = System.currentTimeMillis();
//						TextView timeTextView = (TextView) findViewById(R.id.timeTextView);
//						long time = stopTime - startTime;
//						int second = (int) time/1000;
//						int comma = (int) time%1000;
//						String strTime = (second + "�b" + comma).toString();
						Date date = new Date(System.currentTimeMillis() - startTime);
						SimpleDateFormat simpleDateFormat = new SimpleDateFormat("ss'�b'SSS");
						TextView timeTextView = (TextView) findViewById(R.id.timeTextView);
						timeTextView.setText(simpleDateFormat.format(date).substring(0, 5));
					}

					// �J�E���g��0�ɂȂ������̏���
					public void onFinish() {
						countDownTimer.cancel();
					}
				}.start();
			}
		});

		Button stopbtn = (Button) findViewById(R.id.stopbtn);
		stopbtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (countDownTimer != null) {
					countDownTimer.cancel();
				}
				startTime = System.currentTimeMillis();

				countDownTimer = new CountDownTimer(60000, 1) {

					// �J�E���g�_�E������
					public void onTick(long millisUntilFinished) {
//						TextView timeTextView = (TextView) findViewById(R.id.timeTextView);
//						int second = (int) millisUntilFinished/1000;
//						int comma = (int) millisUntilFinished%1000;
//						timeTextView.setText((second + "�b" + comma).toString());
						Date date = new Date(startTime - System.currentTimeMillis());
						SimpleDateFormat simpleDateFormat = new SimpleDateFormat("ss'�b'SSS");
						TextView timeTextView = (TextView) findViewById(R.id.timeTextView);
						timeTextView.setText(simpleDateFormat.format(date).substring(0, 5));
					}

					// �J�E���g��0�ɂȂ������̏���
					public void onFinish() {
						countDownTimer.cancel();
					}
				}.start();
			}
		});
	}

	@Override
	protected void onPause() {
		super.onPause();
		cancelTimer();
	}

	//�J�E���g���~�߂�
	private void cancelTimer() {
		if (countDownTimer != null) {
			countDownTimer.cancel();
		}
	}}